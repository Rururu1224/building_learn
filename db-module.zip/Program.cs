using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using Serilog;
using ISO11820WinForms.Core;
using ISO11820WinForms.DB;
using ISO11820WinForms.Services;
using ISO11820WinForms.UI;
// 消除 System.AppContext 与自定义 AppContext 的二义性
using AppContext = ISO11820WinForms.Core.AppContext;

namespace ISO11820WinForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            var config = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
                .Build();

            // 修复1：自动创建Logs日志文件夹，保证日志正常输出，方便排查数据库错误
            string logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            if (!Directory.Exists(logDir))
            {
                Directory.CreateDirectory(logDir);
            }

            Log.Logger = new LoggerConfiguration()
                .WriteTo.File(
                    Path.Combine(logDir, "ISO11820_.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 30)
                .CreateLogger();

            try
            {
                Log.Information("ISO11820 仿真系统启动");
                string dbRelPath = config["Database:SqlitePath"] ?? "Data\\ISO11820.db";
                string dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, dbRelPath);
                string baseDir = config["FileStorage:BaseDirectory"] ?? "D:\\ISO11820";
                string testDataDir = config["FileStorage:TestDataDirectory"] ?? "D:\\ISO11820\\TestData";
                string reportDir = config["Report:OutputDirectory"] ?? "D:\\ISO11820\\Reports";
                double initialTemp = double.Parse(config["Simulation:InitialFurnaceTemp"] ?? "720");
                double targetTemp = double.Parse(config["Simulation:TargetFurnaceTemp"] ?? "750");
                double heatingRate = double.Parse(config["Simulation:HeatingRatePerSecond"] ?? "40");
                double fluctuation = double.Parse(config["Simulation:TempFluctuation"] ?? "0.5");
                double stableThreshold = double.Parse(config["Simulation:StableThreshold"] ?? "3.0");
                int constPower = int.Parse(config["Hardware:ConstPower"] ?? "2048");

                var ctx = AppContext.Instance;
                ctx.DbPath = dbPath;
                ctx.BaseDirectory = baseDir;
                ctx.TestDataDirectory = testDataDir;
                ctx.ReportDirectory = reportDir;
                ctx.InitialFurnaceTemp = initialTemp;
                ctx.TargetFurnaceTemp = targetTemp;
                ctx.HeatingRatePerSecond = heatingRate;
                ctx.TempFluctuation = fluctuation;
                ctx.StableThreshold = stableThreshold;
                ctx.ConstPower = constPower;

                // 修复2：单独捕获数据库初始化异常，建表失败直接终止程序，不会继续查表报错
                Log.Information("开始初始化数据库，文件路径：{DbPath}", dbPath);
                try
                {
                    DbHelper.EnsureDatabase(dbPath);
                    Log.Information("数据库初始化、建表、基础数据插入完成");
                }
                catch (Exception dbInitErr)
                {
                    Log.Fatal(dbInitErr, "数据库初始化失败，数据表无法创建");
                    MessageBox.Show($"数据库初始化失败，无法生成所需数据表：\n{dbInitErr.Message}", "数据库致命错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var dbHelper = new DbHelper(dbPath);
                ctx.DbHelper = dbHelper;

                Log.Information("加载设备 apparatus 表数据");
                var apparatus = dbHelper.GetApparatus();
                ctx.ApparatusId = apparatus.Id.ToString();
                ctx.ApparatusName = apparatus.Name;
                ctx.ApparatusCheckDate = apparatus.CheckF;

                var stateMachine = new TestStateMachine(
                    initialTemp, targetTemp, heatingRate, fluctuation, stableThreshold);
                ctx.StateMachine = stateMachine;
                var fileHelper = new FileHelper(baseDir, testDataDir, reportDir);
                Log.Information("系统全部模块初始化完成，准备打开登录界面");
                stateMachine.Start();
                Application.Run(new LoginForm());
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "程序全局启动异常");
                MessageBox.Show($"程序启动失败：{ex.Message}\n\n{ex.StackTrace}", "启动错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }
    }
}